from google.cloud import storage
from google.api_core.exceptions import GoogleAPIError
import requests
import pandas as pd
import json

def decorator_try_except(func):
    """
    A decorator for exception handling in class methods.

    This decorator wraps a class method and captures exceptions of type `GoogleAPIError`.
    If an exception occurs, it is logged as an error using the logging library.
    """
    def try_func(self, *args):
        try:
            return func(self, *args)
        except GoogleAPIError as e:
            print( f"ERROR {e}" ) 
    return try_func


class CloudStorage:
    """
    A class for interacting with Google Cloud Storage, including operations such as creating buckets, uploading and downloading objects,
    handling JSON, and more.
    """
    def __init__(self):
        self.storage_client = storage.Client()

    @decorator_try_except
    def create_bucket(self, bucket_name: str, location : str ='us-central1'):
        """
        Creates a new bucket in Google Cloud Storage.
        Args:
            bucket_name (str): The name of the bucket to be created.
            storage_class (str, optional): The storage class of the bucket. Default is 'STANDARD'.
            location (str, optional): The location of the bucket. Default is 'us-central1'.
        """ 
        bucket = self.storage_client.create_bucket(bucket_name, location=location)     
        return f'Bucket {bucket.name} successfully created.'

    @decorator_try_except
    def list_buckets(self):
        """
        Lists all buckets in the Google Cloud project.

        Returns:
            List[str]: A list of bucket names.
        """
        buckets = self.storage_client.list_buckets()
        list_buckets = []
        for item in buckets:
            list_buckets.append(item.name)
        return list_buckets

    @decorator_try_except
    def upload_object(self, bucket_name: str, name_file: str, source_file_name: str, folder: str=None):
        """
        Uploads an object to a bucket in Google Cloud Storage.
        Args:
            bucket_name (str): The name of the target bucket.
            name_file (str): The name of the file in the bucket.
            source_file_name (str): The name of the local source file.
            folder (str, optional): The folder in the bucket where the file will be stored.
        """
        if folder is not None:
            name_file = f"{folder}/{name_file}"
        bucket = self.storage_client.get_bucket(bucket_name)
        blob = bucket.blob(name_file)
        blob.upload_from_filename(source_file_name)
        print('Object Uploaded with Sucess') 


    @decorator_try_except
    def list_objects_buckets(self, bucket_name: str, folder = None) -> str:
        """
        Lists all objects in a specified bucket.
        Args:
            bucket_name (str): The name of the target bucket.
        """
        bucket = self.storage_client.get_bucket(bucket_name)
        blobs = bucket.list_blobs()
        list_files = []
        for item in blobs:
            list_files.append(item.name)
        if folder is not None:
            list_files = list(filter(lambda item : folder in item, list_files))
        return list_files

    @decorator_try_except
    def delete_file(self, bucket_name: str, name_file: str):
        """
        Deletes a file from a bucket.
        Args:
            bucket_name (str): The name of the target bucket.
            name_file (str): The name of the file to be deleted.
        """
        bucket = self.storage_client.get_bucket(bucket_name)
        blob = bucket.blob(name_file)
        blob.delete()
        print("INFO File {} deleted.".format(blob.name) )

    @decorator_try_except
    def delete_bucket(self, bucket_name: str):
        """
        Deletes a bucket and all its contents.
        Args:
            bucket_name (str): The name of the bucket to be deleted.
        """
        bucket = self.storage_client.get_bucket(bucket_name)
        bucket.delete()
        print("INFO Bucket {} deleted.".format(bucket.name))


    @decorator_try_except
    def download_object(self, bucket_name: str, file_name: str, output_file_name: str):
        """
        Downloads an object from a bucket to a local file.
        Args:
            bucket_name (str): The name of the target bucket.
            file_name (str): The name of the object in the bucket.
            output_file_name (str): The name of the local output file.
        """
        bucket = self.storage_client.get_bucket(bucket_name)
        blob = bucket.get_blob(file_name)
        blob.download_to_filename(output_file_name)

